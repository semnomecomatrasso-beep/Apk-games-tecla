package com.example.teclasoverlay

object KeyBus {
    @Volatile
    var listener: ((String, Boolean) -> Unit)? = null
}
