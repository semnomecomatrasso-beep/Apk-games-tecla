package com.example.teclasoverlay

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

// Só observa as teclas W, A, S e D para acender as teclas na tela.
// Não grava nada e não bloqueia nenhuma tecla (retorna false).
class KeyAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val k = when (event.keyCode) {
            KeyEvent.KEYCODE_W -> "W"
            KeyEvent.KEYCODE_A -> "A"
            KeyEvent.KEYCODE_S -> "S"
            KeyEvent.KEYCODE_D -> "D"
            else -> null
        }
        if (k != null) {
            if (event.action == KeyEvent.ACTION_DOWN) KeyBus.listener?.invoke(k, true)
            if (event.action == KeyEvent.ACTION_UP) KeyBus.listener?.invoke(k, false)
        }
        return false
    }
}
